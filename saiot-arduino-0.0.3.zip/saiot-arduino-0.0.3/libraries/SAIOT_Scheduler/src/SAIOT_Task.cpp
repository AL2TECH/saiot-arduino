/*
 * 	SAIOT_Task.cpp
 *	Description: task module
 *  Created on: 21 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#include "SAIOT_Task.h"
#include "Arduino.h"
#include "SAIOT_System_Time.h"
/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
SAIOT_Task::SAIOT_Task()
{
    // avoid clear stuff here!!! since data are saved in RTC memory, could be erased by class constructor in startup phase!
}
SAIOT_Task::SAIOT_Task(const uint8_t task_id, const uint32_t interval_time, task_callback callback)
{
    _taskId = task_id;
    _taskEnabled = true;
    _intervalTime = interval_time;
    _nextRunTime = System_Time.get_time_epoch_format();
    _callback = callback;
}
SAIOT_Task::SAIOT_Task(const uint8_t task_id, const uint32_t interval_time, const uint32_t next_run_time, task_callback callback, const bool task_enabled)
{
    _taskId = task_id;
    _taskEnabled = task_enabled;
    _intervalTime = interval_time;
    _nextRunTime = next_run_time;
    _callback = callback;
}

uint8_t SAIOT_Task::getTaskId(void)
{
    return _taskId;
}
void SAIOT_Task::setTaskEnable(bool task_enable)
{
    _taskEnabled = task_enable;
}
bool SAIOT_Task::getTaskEnable(void)
{
    return _taskEnabled;
}
void SAIOT_Task::setTaskNextRunTime(const uint32_t next_run_time)
{
    _nextRunTime = next_run_time;
}
uint32_t SAIOT_Task::getTaskNextRunTime(void)
{
    return _nextRunTime;
}
void SAIOT_Task::setTaskIntervalTime(const uint32_t interval_time)
{
    _intervalTime = interval_time;
}
uint32_t SAIOT_Task::getTaskIntervalTime(void)
{
    return _intervalTime;
}
void SAIOT_Task::assignTaskCallback(task_callback callback)
{
    _callback = callback;
}

void SAIOT_Task::execute(void)
{
    _callback(this);
}

void SAIOT_Task::print(void)
{

    Serial.printf("TASK ID: %u\r\n", _taskId);
    Serial.printf("TASK ENABLED: %u\r\n", _taskEnabled);
    Serial.printf("TASK NEXT RUN TIME: %lu\r\n", _nextRunTime);
    Serial.printf("TASK INTERVAL TIME: %lu sec\r\n", _intervalTime);
    Serial.printf("TASK CALLBACK ADDR: 0x%08lx\r\n", (uint32_t)_callback);
    Serial.println("");
}
void SAIOT_Task::clear(void)
{
    _taskId = 0;
    _taskEnabled = false;
    _intervalTime = 0;
    _nextRunTime = 0;
    _callback = nullptr;
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/
