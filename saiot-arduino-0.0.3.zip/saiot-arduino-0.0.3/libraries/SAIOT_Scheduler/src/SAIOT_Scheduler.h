/*
 * 	SAIOT_Scheduler.h
 *	Description: Scheduler module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef _SAIOT_SCHEDULER_H_
#define _SAIOT_SCHEDULER_H_

#include <stdint.h>

#include <SAIOT_Task.h>

#define SCHEDULER_NUMBER_TASKS 10

class SAIOT_Scheduler
{
public:
  SAIOT_Scheduler(void);

  uint32_t run(void);
  uint32_t getNextRunTime(void);

  void addTask(SAIOT_Task *p_task);
  void removeTask(const uint8_t task_id);

  SAIOT_Task getTask(const uint8_t task_sel_id);

  void printTasks(void);
  void removeAllTasks(void);

private:
  SAIOT_Task _tasks[SCHEDULER_NUMBER_TASKS];
};

extern SAIOT_Scheduler Scheduler;

#endif
