/*
 * 	SAIOT_Board.cpp
 *	Description: board module
 *  Created on: 24 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#include "SAIOT_Board.h"

#include "Arduino.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/
#define WIFI_CONN_TIMEOUT 10
#define SEC_TO_MSEC_FACTOR 1000
/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
SAIOT_Board::SAIOT_Board(void)
{
    _wifi = &SAIOTWiFi;
    mqtt = &MQTT;
    led = &LED;
    button = &BUTTON;
    imu = &IMU;
    _scheduler = &Scheduler;
    expansion = &EXPANSION;
    _power_manager = &Power_Manager;
    _system_time = &System_Time;
    lowPowerEnable = false;
    wifiConnTimeout = WIFI_CONN_TIMEOUT;
    status = BOARD_STATUS_OK;
}

board_status_t SAIOT_Board::begin(const char *ssid, const char *pwd, const long time_offset_sec)
{
    status = BOARD_STATUS_OK;
    if (ssid != nullptr)
    {
        strcpy(_wifi_ssid, ssid);
    }
    if (pwd != nullptr)
    {
        strcpy(_wifi_pwd, pwd);
    }
    if (_power_manager->get_wakeup_state() != WAKEUP_STATE_DEEP_SLEEP) // only if is NOT woken by deep sleep the time must be configured!!!
    {
        if (!wifiConnect())
        {
            return status;
        }
        if (!_system_time->update_time_NTP(time_offset_sec))
        {
            status = BOARD_STATUS_NTP_ERROR;
            return status;
        }
        if (!wifiDisconnect())
        {
            return status;
        }
    }

    return status;
}

void SAIOT_Board::addTasks(SAIOT_Task tasks[], uint8_t num_tasks)
{
    if (_power_manager->get_wakeup_state() != WAKEUP_STATE_DEEP_SLEEP) // only if is NOT woken by deep sleep the tasks must be added
    {
        for (uint8_t i = 0; i < num_tasks; i++)
        {
            _scheduler->addTask(&tasks[i]);
        }
    }
}

bool SAIOT_Board::wifiConnect(void)
{
    if (!_wifi->connect(_wifi_ssid, _wifi_pwd, wifiConnTimeout))
    {
        status = BOARD_STATUS_WIFI_ERROR;
        return false;
    }
    return true;
}
bool SAIOT_Board::wifiDisconnect(void)
{
    if (!_wifi->disconnect(false))
    {
        status = BOARD_STATUS_WIFI_ERROR;
        return false;
    }
    return true;
}
bool SAIOT_Board::isWifiConnected(void)
{
    return _wifi->isConnected();
}
uint32_t SAIOT_Board::getTimeEpochFormat(void)
{
    return _system_time->get_time_epoch_format();
}
void SAIOT_Board::loop(void)
{
    uint32_t delay_time;
    delay_time = _scheduler->run();
    if (lowPowerEnable)
    {
        _power_manager->enter_deep_sleep(delay_time - BOARD_STARTUP_DELAY_SEC);
    }
    else
    {
        delay(delay_time * SEC_TO_MSEC_FACTOR);
    }
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/

// Instance of the SAIOT_Board;
SAIOT_Board BOARD;