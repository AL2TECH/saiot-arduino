/*
 * 	SAIOT_Board.h
 *	Description: button module
 *  Created on: 24 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef _SAIOT_BOARD_H_
#define _SAIOT_BOARD_H_

#include "SAIOT_WiFi.h"
#include "SAIOT_MQTT.h"
#include "SAIOT_BUTTON.h"
#include "SAIOT_LED.h"
#include "SAIOT_LSM6DSOX.h"
#include "SAIOT_Power_Manager.h"
#include "SAIOT_Scheduler.h"
#include "SAIOT_System_Time.h"
#include "SAIOT_Expansion.h"
#include "SAIOT_Task.h"
#include <stdint.h>

#define NUM_MAX_CHAR 128
typedef enum {
  BOARD_STATUS_OK = 0,
  BOARD_STATUS_WIFI_ERROR = 1, //error in wifi connection
  BOARD_STATUS_NTP_ERROR = 2, //error in setting time using Network Time Protocol
  //put here other error status
  BOARD_STATUS_UNKNOWN_ERROR = 255
} board_status_t;

class SAIOT_Board
{

public:
  SAIOT_Board(void);
  board_status_t begin(const char *ssid, const char *pwd, const long time_offset_sec); //test wifi connection and set time using NTP
  void addTasks(SAIOT_Task tasks[], uint8_t num_tasks);
  bool wifiConnect(void);
  bool wifiDisconnect(void);
  bool isWifiConnected(void);
  uint32_t getTimeEpochFormat(void);
  void loop(void);

public: // public member variables
  SAIOT_MQTT *mqtt;
  SAIOT_LED *led;
  SAIOT_BUTTON *button;
  SAIOT_LSM6DSOXClass *imu;
  SAIOT_Expansion* expansion;

  bool lowPowerEnable;
  board_status_t status;
  long wifiConnTimeout;


private:
  SAIOT_WiFi *_wifi;
  SAIOT_Scheduler *_scheduler;
  SAIOT_Power_Manager *_power_manager;
  SAIOT_System_Time *_system_time;
  char _wifi_ssid [NUM_MAX_CHAR];
  char _wifi_pwd [NUM_MAX_CHAR];
};

extern SAIOT_Board BOARD;

#endif
