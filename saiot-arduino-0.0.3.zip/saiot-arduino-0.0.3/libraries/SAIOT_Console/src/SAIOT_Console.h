/*
 * 	SAIOT_console.h
 *	Description: console module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef  _SAIOT_CONSOLE_H_
#define  _SAIOT_CONSOLE_H_

#include "Arduino.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

// BOARD PACKAGE VERSION
#define SAIOT_BOARD_PACKAGE_VERSION "0.0.3"

//CONSOLE FLAG Enable
#define CONSOLE_PRINT_MENU

// NB_console_TEST max number of console tests that could be implemented
#define CONSOLE_MAX_NUM_TEST 80

#define CONSOLE_EOC '\r'
#define CONSOLE_COMMAND_SEP " "

// test_function pointer type definition
/**	@brief	Single test function.
*	@param[in] Argument string entered on the command line.
*	@return Void.
*/
typedef void (*p_test_function)(const String argument);

/**
* Contains the required configuration information for a single CONSOLE Test
*/
typedef struct test_config_s {
    String  menu_string;
    String  cmd_string;
     p_test_function p_test; ///< Function to call when the related CONSOLE Test is requested
} test_config_t;

class SAIOT_Console
{
  public:

    SAIOT_Console(void);
    bool add_console_test(const test_config_t *test_configuration);
    void run_console(void);

  private:

    /**
    * Contains console input command and argument
    */
    typedef struct console_input_s{
	    String	command;
	    String  argument;
    } console_input_t;

    test_config_t _console_test[CONSOLE_MAX_NUM_TEST];
    uint8_t _console_test_head;
    console_input_t _console_input;

    bool _get_console_input();
    void _run_console_framework_print_menu(void);
    void _run_framework_test_execution(void);

    void _add_console_tests(void);

};

extern SAIOT_Console Console;

#endif

