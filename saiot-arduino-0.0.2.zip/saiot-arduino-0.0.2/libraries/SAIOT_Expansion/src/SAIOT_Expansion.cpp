/*
 * 	SAIOT_Expansion.cpp
 *	Description: expansion module
 *  Created on: 21 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#include "SAIOT_Expansion.h"
#include <SAIOT_Console.h>


/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/
#if EXP_GPIOS_NUMBER > 0
static const uint8_t m_board_exp_gpios_list[EXP_GPIOS_NUMBER] = EXP_GPIO_LIST;
#endif

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/
static void _exp_gpio_set_mode_test_func(const String argument);
static void _exp_gpio_read_test_func(const String argument);
static void _exp_gpio_write_test_func(const String argument);
static void _exp_serial_begin_test_func(const String argument);
static void _exp_serial_end_test_func(const String argument);
static void _exp_serial_println_test_func(const String argument);
static void _exp_serial_read_string_test_func(const String argument);
/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
SAIOT_Expansion::SAIOT_Expansion(void)
{
}
void SAIOT_Expansion::pinModeExp(const uint8_t exp_gpio_id, const uint8_t mode)
{
    pinMode(m_board_exp_gpios_list[exp_gpio_id], mode);
}

uint8_t SAIOT_Expansion::digitaReadExp(const uint8_t exp_gpio_id)
{
    return digitalRead(m_board_exp_gpios_list[exp_gpio_id]);
}

void SAIOT_Expansion::digitalWriteExp(const uint8_t exp_gpio_id, const uint8_t value)
{
    digitalWrite(m_board_exp_gpios_list[exp_gpio_id], value);
}

void SAIOT_Expansion::serialBeginExp(const unsigned long speed, const uint8_t config)
{
    Serial0.begin(speed, config);
}

void SAIOT_Expansion::serialEndExp(void)
{
    Serial0.end();
}
void SAIOT_Expansion::setTimeoutExp(const long time)
{
    Serial0.setTimeout(time);
}
int SAIOT_Expansion::availableExp(void)
{
    return Serial0.available();
}
int SAIOT_Expansion::availableForWriteExp(void)
{
    return Serial0.availableForWrite();
}
void SAIOT_Expansion::printExp(String string)
{
    Serial0.print(string);
}
void SAIOT_Expansion::printlnExp(String string)
{
    Serial0.println(string);
}
size_t SAIOT_Expansion::writeExp(const uint8_t buffer [], int len)
{
    return Serial0.write(buffer, len);
}
String SAIOT_Expansion::readStringExp(void)
{
    return Serial0.readString();
}
size_t SAIOT_Expansion::readBytesExp(uint8_t buffer [], int len)
{
    return Serial0.readBytes(buffer, len);
}
void SAIOT_Expansion::flush(void)
{
    Serial0.flush();
}

void SAIOT_Expansion::add_console_tests(void)
{
    test_config_t exp_gpio_set_mode_test = {.menu_string = "exp_gpio_set gpio_id mode(0->INPUT, 1->INPUT_PULLUP, 2->OUTPUT)",
                                            .cmd_string = "exp_gpio_set",
                                            .p_test = _exp_gpio_set_mode_test_func};

    Console.add_console_test(&exp_gpio_set_mode_test);

    test_config_t exp_gpio_read_test = {.menu_string = "exp_gpio_read gpio_id",
                                        .cmd_string = "exp_gpio_read",
                                        .p_test = _exp_gpio_read_test_func};

    Console.add_console_test(&exp_gpio_read_test);

    test_config_t exp_gpio_write_test = {.menu_string = "exp_gpio_write gpio_id value(0/1)",
                                         .cmd_string = "exp_gpio_write",
                                         .p_test = _exp_gpio_write_test_func};

    Console.add_console_test(&exp_gpio_write_test);

    test_config_t exp_serial_begin_test = {.menu_string = "exp_ser_begin speed",
                                           .cmd_string = "exp_ser_begin",
                                           .p_test = _exp_serial_begin_test_func};

    Console.add_console_test(&exp_serial_begin_test);

    test_config_t exp_serial_end_test = {.menu_string = "exp_ser_end",
                                         .cmd_string = "exp_ser_end",
                                         .p_test = _exp_serial_end_test_func};

    Console.add_console_test(&exp_serial_end_test);

    test_config_t exp_serial_println_test = {.menu_string = "exp_ser_println string",
                                             .cmd_string = "exp_ser_println",
                                             .p_test = _exp_serial_println_test_func};

    Console.add_console_test(&exp_serial_println_test);

    test_config_t exp_serial_read_string_test = {.menu_string = "exp_ser_read_str",
                                             .cmd_string = "exp_ser_read_str",
                                             .p_test = _exp_serial_read_string_test_func};

    Console.add_console_test(&exp_serial_read_string_test);
}


/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/
static void _exp_gpio_set_mode_test_func(const String argument)
{
    uint8_t gpio_id = 0;
    uint8_t gpio_mode = 0;
    sscanf(argument.c_str(), "%u %u", &gpio_id, &gpio_mode);
    switch (gpio_mode)
    {
    case 0:
        gpio_mode = INPUT;
        break;
    case 1:
        gpio_mode = INPUT_PULLUP;
        break;
    case 2:
        gpio_mode = OUTPUT;
        break;
    default:
        break;
    }
    EXPANSION.pinModeExp(gpio_id, gpio_mode);
    Serial.println("EXP_GPIO SET SUCCESSFUL");
}

static void _exp_gpio_read_test_func(const String argument)
{
    uint8_t gpio_id = (uint8_t)strtoul(argument.c_str(), NULL, 10);
    Serial.println("EXP GPIO: " + String(gpio_id) + " read value: " + String(EXPANSION.digitaReadExp(gpio_id)));
}

static void _exp_gpio_write_test_func(const String argument)
{
    uint8_t gpio_id = 0;
    uint8_t gpio_value = 0;
    sscanf(argument.c_str(), "%u %u", &gpio_id, &gpio_value);
    EXPANSION.digitalWriteExp(gpio_id, gpio_value);
    Serial.println("EXP GPIO: " + String(gpio_id) + " write value: " + String(gpio_value));
}

static void _exp_serial_begin_test_func(const String argument)
{
    unsigned long speed = strtoul(argument.c_str(), NULL, 10);
    EXPANSION.serialBeginExp(speed);
    Serial.println("EXP SERIAL BEGIN WITH SPEED: " + String(speed));
}

static void _exp_serial_end_test_func(const String argument)
{
    EXPANSION.serialEndExp();
    Serial.println("EXP SERIAL END");
}

static void _exp_serial_println_test_func(const String argument)
{
    EXPANSION.printlnExp(argument);
    Serial.println("EXP SERIAL PRINT: " + argument);
}

static void _exp_serial_read_string_test_func(const String argument){
    Serial.println("EXP SERIAL READ STRING " + EXPANSION.readStringExp());
}
// Instance of the SAIOT_Expansion;
SAIOT_Expansion EXPANSION;