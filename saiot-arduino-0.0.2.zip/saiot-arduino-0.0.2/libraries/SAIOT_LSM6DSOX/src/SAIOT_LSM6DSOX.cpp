/*
  This file is part of the Arduino_LSM6DSOX library.
  Copyright (c) 2021 Arduino SA. All rights reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "SAIOT_LSM6DSOX.h"
#include <SAIOT_Console.h>
#include <Arduino.h>

#define IMU_STARTUP_MSEC 100

#define LSM6DSOX_ADDRESS 0x6A
#define LSM6DSOX_INT1_CTRL 0X0D
#define LSM6DSOX_WHO_AM_I_REG 0X0F
#define LSM6DSOX_CTRL1_XL 0X10
#define LSM6DSOX_CTRL2_G 0X11
#define LSM6DSOX_CTRL3_C 0X12

#define LSM6DSOX_STATUS_REG 0X1E

#define LSM6DSOX_CTRL6_C 0X15
#define LSM6DSOX_CTRL7_G 0X16
#define LSM6DSOX_CTRL8_XL 0X17

#define LSM6DSOX_OUT_TEMP_L 0X20
#define LSM6DSOX_OUT_TEMP_H 0X21

#define LSM6DSOX_OUTX_L_G 0X22
#define LSM6DSOX_OUTX_H_G 0X23
#define LSM6DSOX_OUTY_L_G 0X24
#define LSM6DSOX_OUTY_H_G 0X25
#define LSM6DSOX_OUTZ_L_G 0X26
#define LSM6DSOX_OUTZ_H_G 0X27

#define LSM6DSOX_OUTX_L_XL 0X28
#define LSM6DSOX_OUTX_H_XL 0X29
#define LSM6DSOX_OUTY_L_XL 0X2A
#define LSM6DSOX_OUTY_H_XL 0X2B
#define LSM6DSOX_OUTZ_L_XL 0X2C
#define LSM6DSOX_OUTZ_H_XL 0X2D

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

static void _imu_start_test_func(const String argument);
static void _imu_read_gyro_test_func(const String argument);
static void _imu_read_acc_test_func(const String argument);
static void _imu_read_temp_test_func(const String argument);
static void _imu_get_int_test_func(const String argument);
static void _imu_write_reg_test_func(const String argument);
static void _imu_read_reg_test_func(const String argument);

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

SAIOT_LSM6DSOXClass::SAIOT_LSM6DSOXClass(TwoWire &wire, uint8_t slaveAddress) : _wire(&wire),
                                                                                _slaveAddress(slaveAddress)
{
#ifdef IMU_POWER_MOSFET_PIN
  pinMode(IMU_POWER_MOSFET_PIN, OUTPUT);
#endif

#ifdef IMU_INTERRUPT_PIN
  pinMode(IMU_INTERRUPT_PIN, INPUT);
#endif
}

SAIOT_LSM6DSOXClass::~SAIOT_LSM6DSOXClass()
{
}

int SAIOT_LSM6DSOXClass::begin()
{
// IMU power up
#ifdef IMU_POWER_MOSFET_PIN
  digitalWrite(IMU_POWER_MOSFET_PIN, HIGH);
  delay(IMU_STARTUP_MSEC);
#endif

  _wire->begin();

  if (!(readRegister(LSM6DSOX_WHO_AM_I_REG) == 0x6C || readRegister(LSM6DSOX_WHO_AM_I_REG) == 0x69))
  {
    end();
    return 0;
  }

  // set the gyroscope control register to work at 104 Hz, 2000 dps and in bypass mode
  writeRegister(LSM6DSOX_CTRL2_G, 0x4C);

  // Set the Accelerometer control register to work at 104 Hz, 4 g,and in bypass mode and enable ODR/4
  // low pass filter (check figure9 of LSM6DSOX's datasheet)
  writeRegister(LSM6DSOX_CTRL1_XL, 0x4A);

  // set gyroscope power mode to high performance and bandwidth to 16 MHz
  writeRegister(LSM6DSOX_CTRL7_G, 0x00);

  // Set the ODR config register to ODR/4
  writeRegister(LSM6DSOX_CTRL8_XL, 0x09);

  return 1;
}

void SAIOT_LSM6DSOXClass::end()
{
  writeRegister(LSM6DSOX_CTRL3_C, 0X04);
  writeRegister(LSM6DSOX_INT1_CTRL, 0X00);

  //put default registers values before those registers (they set power down mode)
  writeRegister(LSM6DSOX_CTRL2_G, 0x00);
  writeRegister(LSM6DSOX_CTRL1_XL, 0x00);

  _wire->end();
  // IMU power uff
#ifdef IMU_POWER_MOSFET_PIN
  delay(IMU_STARTUP_MSEC);
  digitalWrite(IMU_POWER_MOSFET_PIN, HIGH);
#endif
}

int SAIOT_LSM6DSOXClass::readAcceleration(float &x, float &y, float &z)
{
  int16_t data[3];

  if (!readRegisters(LSM6DSOX_OUTX_L_XL, (uint8_t *)data, sizeof(data)))
  {
    x = NAN;
    y = NAN;
    z = NAN;

    return 0;
  }

  x = data[0] * 4.0 / 32768.0;
  y = data[1] * 4.0 / 32768.0;
  z = data[2] * 4.0 / 32768.0;

  return 1;
}

int SAIOT_LSM6DSOXClass::accelerationAvailable()
{
  if (readRegister(LSM6DSOX_STATUS_REG) & 0x01)
  {
    return 1;
  }

  return 0;
}

float SAIOT_LSM6DSOXClass::accelerationSampleRate()
{
  return 104.0F;
}

int SAIOT_LSM6DSOXClass::readGyroscope(float &x, float &y, float &z)
{
  int16_t data[3];

  if (!readRegisters(LSM6DSOX_OUTX_L_G, (uint8_t *)data, sizeof(data)))
  {
    x = NAN;
    y = NAN;
    z = NAN;

    return 0;
  }

  x = data[0] * 2000.0 / 32768.0;
  y = data[1] * 2000.0 / 32768.0;
  z = data[2] * 2000.0 / 32768.0;

  return 1;
}

int SAIOT_LSM6DSOXClass::gyroscopeAvailable()
{
  if (readRegister(LSM6DSOX_STATUS_REG) & 0x02)
  {
    return 1;
  }

  return 0;
}

int SAIOT_LSM6DSOXClass::readTemperature(int &temperature_deg)
{
  float temperature_float = 0;
  readTemperatureFloat(temperature_float);

  temperature_deg = static_cast<int>(temperature_float);

  return 1;
}

int SAIOT_LSM6DSOXClass::readTemperatureFloat(float &temperature_deg)
{
  /* Read the raw temperature from the sensor. */
  int16_t temperature_raw = 0;

  if (readRegisters(LSM6DSOX_OUT_TEMP_L, reinterpret_cast<uint8_t *>(&temperature_raw), sizeof(temperature_raw)) != 1)
  {
    return 0;
  }

  /* Convert to °C. */
  static int const TEMPERATURE_LSB_per_DEG = 256;
  static int const TEMPERATURE_OFFSET_DEG = 25;

  temperature_deg = (static_cast<float>(temperature_raw) / TEMPERATURE_LSB_per_DEG) + TEMPERATURE_OFFSET_DEG;

  return 1;
}

int SAIOT_LSM6DSOXClass::temperatureAvailable()
{
  if (readRegister(LSM6DSOX_STATUS_REG) & 0x04)
  {
    return 1;
  }

  return 0;
}

float SAIOT_LSM6DSOXClass::gyroscopeSampleRate()
{
  return 104.0F;
}

int SAIOT_LSM6DSOXClass::getIntStatus(void)
{
#ifdef IMU_INTERRUPT_PIN
  return digitalRead(IMU_INTERRUPT_PIN);
#else
  return 0;
#endif
}

int SAIOT_LSM6DSOXClass::readRegister(uint8_t address)
{
  uint8_t value;

  if (readRegisters(address, &value, sizeof(value)) != 1)
  {
    return -1;
  }

  return value;
}

int SAIOT_LSM6DSOXClass::readRegisters(uint8_t address, uint8_t *data, size_t length)
{

  _wire->beginTransmission(_slaveAddress);
  _wire->write(address);

  if (_wire->endTransmission(false) != 0)
  {
    return -1;
  }

  if (_wire->requestFrom(_slaveAddress, length) != length)
  {
    return 0;
  }

  for (size_t i = 0; i < length; i++)
  {
    *data++ = _wire->read();
  }
  return 1;
}

int SAIOT_LSM6DSOXClass::writeRegister(uint8_t address, uint8_t value)
{
  _wire->beginTransmission(_slaveAddress);
  _wire->write(address);
  _wire->write(value);
  if (_wire->endTransmission() != 0)
  {
    return 0;
  }
  return 1;
}

void SAIOT_LSM6DSOXClass::add_console_tests(void)
{
  test_config_t imu_start_test = {.menu_string = "imu_start <1/0>",
                                  .cmd_string = "imu_start",
                                  .p_test = _imu_start_test_func};

  Console.add_console_test(&imu_start_test);

  test_config_t imu_read_gyro_test = {.menu_string = "imu_read_gyro",
                                      .cmd_string = "imu_read_gyro",
                                      .p_test = _imu_read_gyro_test_func};

  Console.add_console_test(&imu_read_gyro_test);

  test_config_t imu_read_acc_test = {.menu_string = "imu_read_acc",
                                     .cmd_string = "imu_read_acc",
                                     .p_test = _imu_read_acc_test_func};

  Console.add_console_test(&imu_read_acc_test);

  test_config_t imu_read_temp_test = {.menu_string = "imu_read_temp",
                                      .cmd_string = "imu_read_temp",
                                      .p_test = _imu_read_temp_test_func};

  Console.add_console_test(&imu_read_temp_test);

  test_config_t imu_get_int_test = {.menu_string = "imu_get_int",
                                    .cmd_string = "imu_get_int",
                                    .p_test = _imu_get_int_test_func};

  Console.add_console_test(&imu_get_int_test);

  test_config_t imu_write_reg_test = {.menu_string = "imu_write_reg reg_addr value (in hex)",
                                      .cmd_string = "imu_write_reg",
                                      .p_test = _imu_write_reg_test_func};

  Console.add_console_test(&imu_write_reg_test);

  test_config_t imu_read_reg_test = {.menu_string = "imu_read_reg reg_addr (in hex)",
                                     .cmd_string = "imu_read_reg",
                                     .p_test = _imu_read_reg_test_func};

  Console.add_console_test(&imu_read_reg_test);
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/
static void _imu_start_test_func(const String argument)
{
  uint8_t start = (uint8_t)strtoul(argument.c_str(), NULL, 10);
  if (start)
  {
    Serial.println("IMU START");
    if (IMU.begin())
    {
      Serial.println("IMU START SUCCESS");
    }
    else
    {
      Serial.println("IMU START FAILED");
    }
  }
  else
  {
    Serial.println("IMU STOP");
    IMU.end();
  }
}

static void _imu_read_gyro_test_func(const String argument)
{
  float x, y, z;
  if (!IMU.gyroscopeAvailable())
  {
    Serial.println("GYRO DATA NOT AVAIL");
    return;
  }
  IMU.readGyroscope(x, y, z);
  Serial.println("GYRO: x: " + String(x) + " y: " + String(y) + " z: " + String(z));
}

static void _imu_read_acc_test_func(const String argument)
{
  float x, y, z;
  if (!IMU.accelerationAvailable())
  {
    Serial.println("ACC DATA NOT AVAIL");
    return;
  }
  IMU.readAcceleration(x, y, z);
  Serial.println("ACC: x: " + String(x) + " y: " + String(y) + " z: " + String(z));
}
static void _imu_read_temp_test_func(const String argument)
{
  float temp;
  if (!IMU.temperatureAvailable())
  {
    Serial.println("TEMPERATURE DATA NOT AVAIL");
    return;
  }
  IMU.readTemperatureFloat(temp);
  Serial.println("TEMPERATURE: " + String(temp));
}

static void _imu_get_int_test_func(const String argument)
{
  Serial.println("IMU INT: " + String(IMU.getIntStatus()));
}

static void _imu_write_reg_test_func(const String argument)
{
  uint8_t reg_addr = 0;
  uint8_t reg_value = 0;
  sscanf(argument.c_str(), "%x %x", &reg_addr, &reg_value);
  Serial.print("REG_ADDR: ");
  Serial.print(reg_addr, HEX);
  Serial.print(" REG_VALUE: ");
  Serial.println(reg_value, HEX);

  if (IMU.writeRegister(reg_addr, reg_value))
  {
    Serial.println("IMU WRITE REG SUCCESS");
  }
  else
  {
    Serial.println("IMU WRITE REG FAILED");
  }
}

static void _imu_read_reg_test_func(const String argument)
{
  uint8_t reg_addr = (uint8_t)strtoul(argument.c_str(), NULL, 16);
  Serial.print("REG_ADDR: ");
  Serial.print(reg_addr, HEX);

  Serial.print(" REGISTER VALUE: ");
  Serial.println(IMU.readRegister(reg_addr), HEX);
}
SAIOT_LSM6DSOXClass IMU(Wire, LSM6DSOX_ADDRESS);
