/*
 * 	SAIOT_WiFi.c
 *	Description: WiFi module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#include "SAIOT_WiFi.h"
#include <SAIOT_Console.h>

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

static void _wifi_connect_test_func(const String argument);
static void _wifi_disconnect_test_func(const String argument);
static void _wifi_is_connected_test_func(const String argument);
static void _wifi_get_status_test_func(const String argument);
/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
SAIOT_WiFi::SAIOT_WiFi(void)
{
}

bool SAIOT_WiFi::connect(const char *ssid, const char *pwd, const unsigned long timeoutLength)
{
    WiFi.begin(ssid, pwd);
    if (WiFi.waitForConnectResult(timeoutLength * 1000) == WL_CONNECTED)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool SAIOT_WiFi::disconnect(bool eraseap)
{
    return WiFi.disconnect(true, eraseap);
}

bool SAIOT_WiFi::isConnected(void)
{
    return WiFi.isConnected();
}

IPAddress SAIOT_WiFi::getIp(void)
{
    return WiFi.localIP();
}

wl_status_t SAIOT_WiFi::getStatus(void){
    return WiFi.status();
}
void SAIOT_WiFi::add_console_tests(void)
{

    test_config_t wifi_conn_test = {.menu_string = "wifi_conn ssid pwd timeout_sec",
                                    .cmd_string = "wifi_conn",
                                    .p_test = _wifi_connect_test_func};

    Console.add_console_test(&wifi_conn_test);

    test_config_t wifi_disc_test = {.menu_string = "wifi_disc",
                                    .cmd_string = "wifi_disc",
                                    .p_test = _wifi_disconnect_test_func};

    Console.add_console_test(&wifi_disc_test);

    test_config_t wifi_is_conn_test = {.menu_string = "wifi_is_conn",
                                       .cmd_string = "wifi_is_conn",
                                       .p_test = _wifi_is_connected_test_func};

    Console.add_console_test(&wifi_is_conn_test);


    test_config_t wifi_get_status_test = {.menu_string = "wifi_get_status",
                                       .cmd_string = "wifi_get_status",
                                       .p_test = _wifi_get_status_test_func};

    Console.add_console_test(&wifi_get_status_test);
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/

static void _wifi_connect_test_func(const String argument)
{
    char ssid[128] = {0};
    char pwd[128] = {0};
    unsigned long timeout = 10;
    sscanf(argument.c_str(), "%[^ ] %[^ ] %u", ssid, pwd, &timeout);
    Serial.println("SSID: " + String(ssid) + " PWD: " + String(pwd) + " CONN TIMEOUT: " + String(timeout));
    if (SAIOTWiFi.connect(ssid, pwd, timeout))
    {
        Serial.println("CONNECTION COMPLETED");
    }
    else
    {
        Serial.println("CONNECTION FAILED");
    }
}

static void _wifi_disconnect_test_func(const String argument)
{
    if (SAIOTWiFi.disconnect(true))
    {
        Serial.println("disconnection completed");
    }
    else
    {
        Serial.println("disconnection failed");
    }
}

static void _wifi_is_connected_test_func(const String argument)
{
    String ip_addr;
    if (SAIOTWiFi.isConnected())
    {
        ip_addr = SAIOTWiFi.getIp().toString();
        Serial.println("Wifi connected with IP: " + ip_addr);
    }
    else
    {
        Serial.println("Wifi NOT connected");
    }
}
static void _wifi_get_status_test_func(const String argument){
    Serial.println("Wifi status: " + String(SAIOTWiFi.getStatus()));
}
// Instance of the SAIOT_WiFi;
SAIOT_WiFi SAIOTWiFi;