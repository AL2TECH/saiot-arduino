/*
 * 	SAIOT_System_Time.c
 *	Description: System time module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#include "SAIOT_System_Time.h"
#include "SAIOT_Console.h"
#include "NTPClient.h"
#include "Arduino.h"
#include <WiFiUdp.h>
#include "SAIOT_WiFi.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

static void _get_time_test_func(const String argument);
static void _set_time_test_func(const String argument);
static void _update_NTP_time_test_func(const String argument);

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
SAIOT_System_Time::SAIOT_System_Time(void)
{
}

uint32_t SAIOT_System_Time::get_time_epoch_format(void)
{

    return (uint32_t)time(NULL);
}

struct tm SAIOT_System_Time::get_time_struct_format(void)
{

    struct tm struct_time;

    uint32_t curr_time = (uint32_t)get_time_epoch_format();
    localtime_r((time_t *)&curr_time, &struct_time);
    return struct_time;
}

void SAIOT_System_Time::set_time_epoch_format(uint32_t time_u32)
{

    struct timeval tv_ts;
    tv_ts.tv_sec = time_u32;
    tv_ts.tv_usec = 0;
    settimeofday(&tv_ts, NULL);
}

void SAIOT_System_Time::set_time_struct_format(struct tm time_tm)
{

    uint32_t curr_time = mktime(&time_tm);
    set_time_epoch_format(curr_time);
}

bool SAIOT_System_Time::update_time_NTP(const long time_offset)
{
    if (!SAIOTWiFi.isConnected())
    {
        return false;
    }
    bool ret = false;
    WiFiUDP ntpUDP;
    NTPClient timeClient(ntpUDP, "pool.ntp.org", time_offset);
    timeClient.begin();
    ret = timeClient.forceUpdate();
    if (ret)
    {
        set_time_epoch_format(timeClient.getEpochTime());
    }
    timeClient.end();
    return ret;
}
void SAIOT_System_Time::add_console_tests(void)
{

    test_config_t get_time_test = {.menu_string = "get_time",
                                   .cmd_string = "get_time",
                                   .p_test = _get_time_test_func};

    Console.add_console_test(&get_time_test);

    test_config_t set_time_test = {.menu_string = "set_time <epoch_hex>",
                                   .cmd_string = "set_time",
                                   .p_test = _set_time_test_func};

    Console.add_console_test(&set_time_test);

    test_config_t update_NTP_time_test = {.menu_string = "update_NTP_time <time_offset> (in seconds)",
                                          .cmd_string = "update_NTP_time",
                                          .p_test = _update_NTP_time_test_func};

    Console.add_console_test(&update_NTP_time_test);
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/

static void _get_time_test_func(const String argument)
{
    uint32_t curr_time = System_Time.get_time_epoch_format();
    Serial.print("CURRENT EPOCH TIME:  ");
    Serial.println(curr_time);
}

static void _set_time_test_func(const String argument)
{
    uint32_t curr_time = (uint32_t)strtol(argument.c_str(), NULL, 16);
    Serial.print("CURRENT EPOCH TIME:  ");
    Serial.println(curr_time);
    System_Time.set_time_epoch_format(curr_time);
}

static void _update_NTP_time_test_func(const String argument)
{
    long offset_time = (uint32_t)strtol(argument.c_str(), NULL, 10);
    if (System_Time.update_time_NTP(offset_time))
    {
        Serial.println("NTP successful time: " + String(System_Time.get_time_epoch_format()));
    }
    else
    {
        Serial.println("NTP failed");
    }
}

// Instance of the SAIOT_System_Time;
SAIOT_System_Time System_Time;