/*
 * 	SAIOT_Task.h
 *	Description: Task module
 *  Created on: 21 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef _SAIOT_TASK_H_
#define _SAIOT_TASK_H_

#include <stdint.h>

class SAIOT_Task;
/**
 * task callback function
 *
 * @param task pointer
 */
typedef void (*task_callback)(SAIOT_Task *);

class SAIOT_Task
{
public:
    SAIOT_Task();
    SAIOT_Task(const uint8_t task_id, const uint32_t interval_time, task_callback callback, const uint32_t offset_time=0, const bool task_enabled=true);
    uint8_t getTaskId(void);
    void setTaskEnable(bool task_enabled);
    bool getTaskEnable(void);
    void setTaskNextRunTime(const uint32_t next_run_time);
    uint32_t getTaskNextRunTime(void);
    void setTaskIntervalTime(const uint32_t interval_time);
    uint32_t getTaskIntervalTime(void);
    void assignTaskCallback(task_callback callback);
    void execute(void);
    void print(void);
    void clear(void);

private:
    uint8_t _taskId;
    bool _taskEnabled;
    uint32_t _nextRunTime;
    uint32_t _intervalTime;
    task_callback _callback;
};

#endif
