/*
 * 	SAIOT_Scheduler.c
 *	Description: Scheduler module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#include "SAIOT_Scheduler.h"
#include "SAIOT_System_Time.h"
#include "Arduino.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

#define SCH_FORCE_RUN_DEL 1

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
SAIOT_Scheduler::SAIOT_Scheduler(void)
{
	//avoid clear stuff here!!! since data are saved in RTC memory, could be erased by class constructor in startup phase!
}

uint32_t SAIOT_Scheduler::run(void)
{

	uint32_t current_time, next_run_time;

	// get current time
	current_time = System_Time.get_time_epoch_format();
	Serial.print("SCHEDULER: RUN AT ");
	Serial.println(current_time);

	for (uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS; i++)
	{
		// if task timer expired run the callback and set the new run time
		if ((_tasks[i].getTaskNextRunTime() <= current_time) && (_tasks[i].getTaskEnable()))
		{
			Serial.print("SCHEDULER: RUN TASK ID ");
			Serial.println(_tasks[i].getTaskId());
			_tasks[i].execute();
			_tasks[i].setTaskNextRunTime(_tasks[i].getTaskNextRunTime() + _tasks[i].getTaskIntervalTime());
		}
	}

	next_run_time = getNextRunTime();
	current_time = System_Time.get_time_epoch_format();

	return (next_run_time - current_time);
}

uint32_t SAIOT_Scheduler::getNextRunTime(void)
{

	uint32_t current_time;
	uint32_t next_run_time = 0xFFFFFFFF;

	// get current time
	current_time = System_Time.get_time_epoch_format();

	// serach for the minimum next_run_time
	for (uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS; i++)
	{
		if ((_tasks[i].getTaskNextRunTime() < next_run_time) && (_tasks[i].getTaskEnable()))
		{
			next_run_time = _tasks[i].getTaskNextRunTime();
		}
	}

	// force immediate execution if the scheduler has some expired tasks
	if (current_time >= next_run_time)
	{
		next_run_time = current_time + SCH_FORCE_RUN_DEL;
	}

	Serial.print("SCHEDULER: NEXT RUN AT ");
	Serial.println(next_run_time);

	return next_run_time;
}

void SAIOT_Scheduler::addTask(SAIOT_Task *p_task)
{
	_tasks[p_task->getTaskId()] = *p_task;
}

void SAIOT_Scheduler::removeTask(const uint8_t task_id){
	_tasks[task_id].clear();
}

SAIOT_Task SAIOT_Scheduler::getTask(const uint8_t task_sel_id)
{
	return _tasks[task_sel_id];
}
void SAIOT_Scheduler::removeAllTasks(void)
{

	for (uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS; i++)
	{

		removeTask(i);
	}
}

void SAIOT_Scheduler::printTasks(void)
{

	for (uint8_t i = 0; i < SCHEDULER_NUMBER_TASKS; i++)
	{
		_tasks[i].print();
	}
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/

// Instance of the SAIOT_Scheduler;
RTC_DATA_ATTR SAIOT_Scheduler Scheduler; /// RTC DATA EXAMPLE https://espressif-docs.readthedocs-hosted.com/projects/arduino-esp32/en/latest/api/deepsleep.html