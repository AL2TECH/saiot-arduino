/*
 * 	SAIOT_Expansion.h
 *	Description: expansion module
 *  Created on: 21 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef _SAIOT_EXPANSION_H_
#define _SAIOT_EXPANSION_H_
#include <stdint.h>
#include "Arduino.h"

class SAIOT_Expansion
{
public:
  SAIOT_Expansion(void);
  void pinModeExp(const uint8_t exp_gpio_id, const uint8_t mode);
  uint8_t digitaReadExp(const uint8_t exp_gpio_id);
  void digitalWriteExp(const uint8_t exp_gpio_id, const uint8_t value);
  // serial methods wrapped from: https://www.arduino.cc/reference/en/language/functions/communication/serial/
  // esp32 ref:  //ref: https://espressif-docs.readthedocs-hosted.com/projects/arduino-esp32/en/latest/guides/tools_menu.html#usb-cdc-on-boot
  void serialBeginExp(const unsigned long speed, const int config = SERIAL_8N1);
  void serialEndExp(void);
  void setTimeoutExp(const long time);
  int availableExp(void);
  int availableForWriteExp(void);
  void printExp(String string);
  void printlnExp(String string);
  size_t writeExp(const uint8_t buffer [], int len);
  String readStringExp(void);
  size_t readBytesExp(uint8_t buffer [], int len);
  void flush(void);

  void add_console_tests(void);

private:
};

extern SAIOT_Expansion EXPANSION;

#endif
