/*
 * 	SAIOT_BUTTON.cpp
 *	Description: button module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#include "SAIOT_BUTTON.h"
#include <SAIOT_Console.h>
#include "Arduino.h"

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/

/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

#if BUTTONS_NUMBER > 0
static const uint8_t m_board_buttons_list[BUTTONS_NUMBER] = BUTTONS_LIST;
#endif

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/
static void _button_read_test_func(const String argument);
/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
SAIOT_BUTTON::SAIOT_BUTTON(void)
{
    for (uint8_t i = 0; i < BUTTONS_NUMBER; i++)
    {
        pinMode(m_board_buttons_list[i], INPUT_PULLUP);
    }
}

int SAIOT_BUTTON::getButtonStatus(const uint8_t button_id)
{
    return digitalRead(m_board_buttons_list[button_id]);
}

void SAIOT_BUTTON::add_console_tests(void)
{

    test_config_t button_read_test = {.menu_string = "btn_read btn_id",
                                      .cmd_string = "btn_read",
                                      .p_test = _button_read_test_func};

    Console.add_console_test(&button_read_test);
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/
static void _button_read_test_func(const String argument)
{
    uint8_t btn_id = (uint8_t)strtoul(argument.c_str(), NULL, 10);
    Serial.println("BTN: " + String(btn_id) + " value: " + String(BUTTON.getButtonStatus(btn_id)));
}

// Instance of the SAIOT_BUTTON;
SAIOT_BUTTON BUTTON;