/*
 * 	SAIOT_MQTT.h
 *	Description: MQTT module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef _SAIOT_MQTT_H_
#define _SAIOT_MQTT_H_
#include <WiFiClient.h>
#include <PubSubClient.h>

class SAIOT_MQTT
{
public:
  SAIOT_MQTT(void);
  ~SAIOT_MQTT(void);
  bool connect(const char *client_id, const char *username, const char *pwd, const char *server, const int port);
  void disconnect(void);
  bool isConnected(void);
  bool publish(const char *topic, const char *payload);
  bool subscribe(const char *topic, MQTT_CALLBACK_SIGNATURE);
  bool unsubscribe(const char *topic);
  bool loop(const long timeout_msec);    // process incoming messages, return true the client is still connected, return false the client is no longer connected
  int getState(void); // REF: https://github.com/knolleary/pubsubclient/blob/v2.8/src/PubSubClient.h
  void add_console_tests(void);

private:
  WiFiClient *_wifiClient;
  PubSubClient *_mqttClient;
};

extern SAIOT_MQTT MQTT;

#endif
