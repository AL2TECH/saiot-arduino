/*
 * 	SAIOT_MQTT.cpp
 *	Description: MQTT module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#include "SAIOT_MQTT.h"
#include <SAIOT_Console.h>
#include <PubSubClient.h>

/*************************************************************************/
/* Defines		                                        				 */
/*************************************************************************/
#define MQTT_TICK_DELAY_MSEC 100
/*************************************************************************/
/* private enum/typedef			                                       	 */
/*************************************************************************/
/************************************************************************/
/*  Extern variables/functions            		                        */
/************************************************************************/

/************************************************************************/
/*  Static global variables                                     	    */
/************************************************************************/

/************************************************************************/
/*  TEST function declaration                                           */
/************************************************************************/

static void _mqtt_connect_test_func(const String argument);
static void _mqtt_disconnect_test_func(const String argument);
static void _mqtt_publish_test_func(const String argument);
static void _mqtt_is_connected_test_func(const String argument);
static void _mqtt_get_state_test_func(const String argument);
/************************************************************************/
/*  Public function definition                                      */
/************************************************************************/

// Class Constructor
SAIOT_MQTT::SAIOT_MQTT(void)
{
    _wifiClient = new WiFiClient();
    _mqttClient = new PubSubClient(*_wifiClient);
}

SAIOT_MQTT::~SAIOT_MQTT(void)
{
    this->disconnect(); // safely disconnect before
    delete _mqttClient;
    delete _wifiClient;
}

bool SAIOT_MQTT::connect(const char *client_id, const char *username, const char *pwd, const char *server, const int port)
{
    _mqttClient->setServer(server, port);
    return _mqttClient->connect(client_id, username, pwd);
}

void SAIOT_MQTT::disconnect(void)
{
    _mqttClient->disconnect();
}

bool SAIOT_MQTT::isConnected(void)
{
    return _mqttClient->connected();
}

bool SAIOT_MQTT::publish(const char *topic, const char *payload)
{
    return _mqttClient->publish(topic, payload);
}
bool SAIOT_MQTT::subscribe(const char *topic, MQTT_CALLBACK_SIGNATURE)
{
    _mqttClient->setCallback(callback);
    return _mqttClient->subscribe(topic, MQTTQOS0); // also MQTTQOS1 allowed
}

bool SAIOT_MQTT::unsubscribe(const char *topic)
{
    return _mqttClient->unsubscribe(topic);
}

bool SAIOT_MQTT::loop(const long timeout_msec)
{
    long timeout_cnt = timeout_msec / MQTT_TICK_DELAY_MSEC;
    while (timeout_cnt > 0)
    {
        if (!_mqttClient->loop())
        {
            return false;
        }
        delay(MQTT_TICK_DELAY_MSEC);
        timeout_cnt = timeout_cnt - 1;
    }
    return true;
}
int SAIOT_MQTT::getState(void)
{
    return _mqttClient->state();
}

void SAIOT_MQTT::add_console_tests(void)
{

    test_config_t mqtt_conn_test = {.menu_string = "mqtt_conn server port",
                                    .cmd_string = "mqtt_conn",
                                    .p_test = _mqtt_connect_test_func};

    Console.add_console_test(&mqtt_conn_test);

    test_config_t mqtt_disc_test = {.menu_string = "mqtt_disc",
                                    .cmd_string = "mqtt_disc",
                                    .p_test = _mqtt_disconnect_test_func};

    Console.add_console_test(&mqtt_disc_test);

    test_config_t mqtt_publish_test = {.menu_string = "mqtt_pub topic payload",
                                       .cmd_string = "mqtt_pub",
                                       .p_test = _mqtt_publish_test_func};

    Console.add_console_test(&mqtt_publish_test);

    test_config_t mqtt_is_connected_test = {.menu_string = "mqtt_is_conn",
                                            .cmd_string = "mqtt_is_conn",
                                            .p_test = _mqtt_is_connected_test_func};

    Console.add_console_test(&mqtt_is_connected_test);

    test_config_t mqtt_get_state_test = {.menu_string = "mqtt_get_state",
                                         .cmd_string = "mqtt_get_state",
                                         .p_test = _mqtt_get_state_test_func};

    Console.add_console_test(&mqtt_get_state_test);
}

/***********************************************************************/
/* Private function definition                                          */
/***********************************************************************/

/************************************************************************/
/*  TEST function definition                                           */
/************************************************************************/
static void _mqtt_connect_test_func(const String argument)
{
    char server[128] = {0};
    int port = 0;
    sscanf(argument.c_str(), "%[^ ] %d", server, &port);
    Serial.println("Server: " + String(server) + " PORT: " + String(port));
    if (MQTT.connect("MQTT_TEST_CLIENT_ID", NULL, NULL, server, port))
    {
        Serial.println("MQTT CONNECTION COMPLETED");
    }
    else
    {
        Serial.println("MQTT CONNECTION FAILED");
    }
}

static void _mqtt_disconnect_test_func(const String argument)
{
    MQTT.disconnect();
    Serial.println("Disconnection completed");
}

static void _mqtt_publish_test_func(const String argument)
{
    char topic[128] = {0};
    char payload[128] = {0};
    sscanf(argument.c_str(), "%[^ ] %[^ ]", topic, payload);
    Serial.println("topic: " + String(topic) + " payload: " + String(payload));
    if (MQTT.publish(topic, payload))
    {
        Serial.println("MQTT PUBLISH COMPLETED");
    }
    else
    {
        Serial.println("MQTT PUBLISH FAILED");
    }
}

static void _mqtt_is_connected_test_func(const String argument)
{
    if (MQTT.isConnected())
    {

        Serial.println("MQTT SERVER CONNECTED");
    }
    else
    {
        Serial.println("MQTT SERVER NOT CONNECTED");
    }
}

static void _mqtt_get_state_test_func(const String argument)
{
    Serial.println("MQTT STATE: " + String(MQTT.getState()));
}
// Instance of the SAIOT_MQTT;
SAIOT_MQTT MQTT;