### SAIOT_Console
  SAIOT Console framework
  
### SAIOT_LED
  SAIOT LED manager library
  
### SAIOT_LSM6DSOX
  Deived from Arduino_LSM6DSOX Library.
  
### SAIOT_System_Time
  SAIOT System Time library

### SAIOT_Power_Manager
  SAIOT Power Manager library
  
### SAIOT_Scheduler
  SAIOT Scheduler library

### SAIOT_WiFi
  SAIOT WiFi library

### SAIOT_MQTT
  SAIOT MQTT library

### SAIOT_BUTTON
  SAIOT BUTTON manager library
  
### Wire
  Arduino compatible I2C driver

### Preferences
  Flash keystore using ESP32 NVS

### WiFi
  Arduino compatible WiFi driver (includes Ethernet driver)
  
## PubSubClient
	MQTT Client library
