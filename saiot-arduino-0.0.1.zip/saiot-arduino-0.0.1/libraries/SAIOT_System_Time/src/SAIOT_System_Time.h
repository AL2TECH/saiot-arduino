/*
 * 	SAIOT_System_Time.h
 *	Description: System Time module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef  _SAIOT_SYSTEM_TIME_H_
#define  _SAIOT_SYSTEM_TIME_H_

#include <stdint.h>

class SAIOT_System_Time
{
  public:

    SAIOT_System_Time(void);
    uint32_t get_time_epoch_format(void);
    struct tm get_time_struct_format(void);
    void set_time_epoch_format(uint32_t time_u32);
    void set_time_struct_format(struct tm time_tm);

    void add_console_tests(void);

  private:

};

extern SAIOT_System_Time System_Time;

#endif


