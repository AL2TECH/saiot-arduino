/*
 * 	SAIOT_Power_Manager.h
 *	Description: Power Manager module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef  _SAIOT_POWER_MANAGER_H_
#define  _SAIOT_POWER_MANAGER_H_

#include <stdint.h>

typedef enum {
  WAKEUP_STATE_RESET,    
  WAKEUP_STATE_DEEP_SLEEP, 
} wakeup_state_t;

class SAIOT_Power_Manager
{
  public:


    SAIOT_Power_Manager(void);
    void enter_deep_sleep(uint32_t wake_up_delay_sec);
    void enter_deep_sleep_until(uint32_t wake_up_time_epoch);
    wakeup_state_t get_wakeup_state(void);

    void add_console_tests(void);

  private:

};

extern SAIOT_Power_Manager Power_Manager;

#endif


