/*
 * 	SAIOT_LED.h
 *	Description: led module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef _SAIOT_LED_H_
#define _SAIOT_LED_H_
#include <stdint.h>
#define SAIOT_LED_R 0
#define SAIOT_LED_G 1
#define SAIOT_LED_B 2

class SAIOT_LED
{
public:
  SAIOT_LED(void);
  void leds_on(void);
  void leds_off(void);
  void led_on(const uint8_t led_id);
  void led_off(const uint8_t led_id);

  void add_console_tests(void);

private:
};

extern SAIOT_LED LED;

#endif
