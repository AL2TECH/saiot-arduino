/*
 * 	SAIOT_BUTTON.h
 *	Description: button module
 *  Created on: 20 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: SANTAGOSTINO
 */

#ifndef _SAIOT_BUTTON_H_
#define _SAIOT_BUTTON_H_

#include <stdint.h>

#define SAIOT_BTN_0 0

class SAIOT_BUTTON
{
public:
  SAIOT_BUTTON(void);

  int getButtonStatus(const uint8_t button_id);
  void add_console_tests(void);

private:
};

extern SAIOT_BUTTON BUTTON;

#endif
