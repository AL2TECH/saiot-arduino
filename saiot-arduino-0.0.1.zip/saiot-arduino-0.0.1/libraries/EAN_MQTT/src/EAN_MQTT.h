/*
 * 	EAN_MQTT.h
 *	Description: MQTT module
 *  Created on: 9 March 2023
 *  Author: Alessandro Longobardi
 *  Company: AL2TECH
 *  Client: AL2TECH
 */

#ifndef  _EAN_MQTT_H_
#define  _EAN_MQTT_H_
#include <WiFiClient.h>
#include <PubSubClient.h>

class EAN_MQTT
{
  public:

    EAN_MQTT(void);
    ~EAN_MQTT(void);
    bool connect(const char* client_id,const char* username, const char* pwd, const char* server, const int port);
    void disconnect(void);
    bool isConnected(void);
    bool publish(const char* topic, const char* payload);
    int getState(void); //REF: https://github.com/knolleary/pubsubclient/blob/v2.8/src/PubSubClient.h
    void add_console_tests(void);
  private:
    WiFiClient* _wifiClient;
    PubSubClient* _mqttClient;


};

extern EAN_MQTT MQTT;

#endif


